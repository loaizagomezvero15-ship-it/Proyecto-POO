﻿using SistemaCitasSpa.Dominio.Elementos;
using SistemaCitasSpa.ModelosDTO;

namespace SistemaCitasSpa.Servicios
{
    public interface ICitaServicio
    {
        Task<IEnumerable<Cita>> ObtenerCitasAsync();
        Task<IEnumerable<Servicio>> ObtenerServiciosAsync();
        Task<string> AgendarCitaAsync(AgendarCitaDTO dto);
    }
}
