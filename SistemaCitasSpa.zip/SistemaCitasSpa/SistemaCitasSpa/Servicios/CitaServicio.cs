﻿using SistemaCitasSpa.Datos;
using SistemaCitasSpa.Dominio.Elementos;
using SistemaCitasSpa.ModelosDTO;

namespace SistemaCitasSpa.Servicios
{
    public class CitaServicio : ICitaServicio
    {
        private readonly IRepositorio<Cita> _citaRepo;
        private readonly IRepositorio<Servicio> _servicioRepo;

        public CitaServicio(IRepositorio<Cita> citaRepo, IRepositorio<Servicio> servicioRepo)
        {
            _citaRepo = citaRepo;
            _servicioRepo = servicioRepo;
        }

        public async Task<IEnumerable<Cita>> ObtenerCitasAsync()
        {
            return await _citaRepo.ObtenerTodosAsync();
        }

        public async Task<IEnumerable<Servicio>> ObtenerServiciosAsync()
        {
            return await _servicioRepo.ObtenerTodosAsync();
        }

        public async Task<string> AgendarCitaAsync(AgendarCitaDTO dto)
        {
            var citasExistentes = await _citaRepo.ObtenerTodosAsync();

            // Validar si la manicurista ya tiene una cita exactamente a la misma hora y fecha
            bool estaOcupado = citasExistentes.Any(c =>
                c.ManicuristaId.ToLower() == dto.ManicuristaId.ToLower() &&
                c.FechaHora == dto.FechaHora);

            if (estaOcupado)
            {
                return "Lo sentimos, el espacio ya está ocupado para esta manicurista en ese horario.";
            }

            // Si está libre, creamos la cita
            var nuevaCita = new Cita
            {
                Id = new Random().Next(1, 1000),
                ClienteNombre = dto.ClienteNombre,
                ManicuristaId = dto.ManicuristaId,
                ServicioId = dto.ServicioId,
                FechaHora = dto.FechaHora
            };

            await _citaRepo.AgregarAsync(nuevaCita);
            return "¡Cita agendada con éxito!";
        }
    }
}
