﻿using SistemaCitasSpa.Dominio.Elementos;

namespace SistemaCitasSpa.Datos
{
    public class IMemoriaRepositorio<T> : IRepositorio<T> where T : class
    {
        private readonly List<T> _elementos = new();

        public IMemoriaRepositorio()
        {
            // Precargamos los servicios con sus precios si es la entidad Servicio
            if (typeof(T) == typeof(Servicio))
            {
                var serviciosIniciales = new List<Servicio>
                {
                    new Servicio { Id = 1, Nombre = "Uñas Acrílicas", Precio = 120000m },
                    new Servicio { Id = 2, Nombre = "Manicure Ruso", Precio = 45000m },
                    new Servicio { Id = 3, Nombre = "Semipermanente", Precio = 56000m }
                };
                _elementos = serviciosIniciales as List<T> ?? _elementos;
            }
        }

        public async Task<IEnumerable<T>> ObtenerTodosAsync()
        {
            return await Task.FromResult(_elementos);
        }

        public async Task AgregarAsync(T entidad)
        {
            _elementos.Add(entidad);
            await Task.CompletedTask;
        }
    }
}
