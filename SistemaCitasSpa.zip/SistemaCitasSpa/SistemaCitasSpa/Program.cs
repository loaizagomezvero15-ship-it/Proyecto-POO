using SistemaCitasSpa.Datos;
using SistemaCitasSpa.Dominio.Elementos;
using SistemaCitasSpa.Servicios;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Inyección de dependencias de tus capas
builder.Services.AddSingleton<IRepositorio<Cita>, IMemoriaRepositorio<Cita>>();
builder.Services.AddSingleton<IRepositorio<Servicio>, IMemoriaRepositorio<Servicio>>();
builder.Services.AddScoped<ICitaServicio, CitaServicio>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "Sistema de Uñas V1");
        options.RoutePrefix = string.Empty; // Abre Swagger automáticamente al iniciar
    });
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();