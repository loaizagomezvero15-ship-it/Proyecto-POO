﻿namespace SistemaCitasSpa.ModelosDTO
{
    public class AgendarCitaDTO
    {
        public string ClienteNombre { get; set; } = string.Empty;
        public string ManicuristaId { get; set; } = string.Empty;
        public int ServicioId { get; set; }
        public DateTime FechaHora { get; set; }
    }
}
