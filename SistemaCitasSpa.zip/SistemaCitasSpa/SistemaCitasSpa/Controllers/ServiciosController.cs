﻿using Microsoft.AspNetCore.Mvc;
using SistemaCitasSpa.Dominio.Elementos;
using SistemaCitasSpa.Servicios;

namespace SistemaCitasSpa.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiciosController : ControllerBase
    {
        private readonly ICitaServicio _servicio;

        public ServiciosController(ICitaServicio servicio)
        {
            _servicio = servicio;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Servicio>>> GetServicios()
        {
            var lista = await _servicio.ObtenerServiciosAsync();
            return Ok(lista);
        }
    }
}
