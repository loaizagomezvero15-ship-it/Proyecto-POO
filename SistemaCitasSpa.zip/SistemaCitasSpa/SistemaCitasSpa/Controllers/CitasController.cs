﻿using Microsoft.AspNetCore.Mvc;
using SistemaCitasSpa.Dominio.Elementos;
using SistemaCitasSpa.ModelosDTO;
using SistemaCitasSpa.Servicios;

namespace SistemaDeUñas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CitasController : ControllerBase
    {
        private readonly ICitaServicio _servicio;

        public CitasController(ICitaServicio servicio)
        {
            _servicio = servicio;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cita>>> GetCitas()
        {
            var citas = await _servicio.ObtenerCitasAsync();
            return Ok(citas);
        }

        [HttpPost("agendar")]
        public async Task<IActionResult> Agendar([FromBody] AgendarCitaDTO dto)
        {
            var resultado = await _servicio.AgendarCitaAsync(dto);

            if (resultado.Contains("ocupado"))
            {
                return BadRequest(new { mensaje = resultado });
            }

            return Ok(new { mensaje = resultado });
        }
    }
}
